#include <dns.h>

int ipsvd_hostname(stralloc *host, char *ip, unsigned int paranoid);
