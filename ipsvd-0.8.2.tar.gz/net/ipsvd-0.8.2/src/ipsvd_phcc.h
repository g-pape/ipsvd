int ipsvd_phcc_init(unsigned int);
unsigned int ipsvd_phcc_add(char *ip);
unsigned int ipsvd_phcc_setpid(int pid);
int ipsvd_phcc_rem(int pid);
void ipsvd_phcc_free(void);
